import sys
import os
import pytest
from pathlib import Path
from playwright.sync_api import sync_playwright

# 🔥 VERY IMPORTANT: add project root to python path
ROOT_DIR = os.path.dirname(os.path.abspath(__file__))
if ROOT_DIR not in sys.path:
    sys.path.insert(0, ROOT_DIR)

SCREENSHOT_DIR = Path("reports/screenshots")

# 🔹 Run tests on Chromium and Firefox


@pytest.fixture(params=["chromium", "firefox"])
def browser_name(request):
    return request.param


@pytest.fixture
def page(browser_name, request):
    with sync_playwright() as p:

        if browser_name == "chromium":
            browser = p.chromium.launch(headless=False)
        elif browser_name == "firefox":
            browser = p.firefox.launch(headless=False)

        context = browser.new_context()
        page = context.new_page()

        yield page

        # Screenshot only if test failed
        rep = getattr(request.node, "rep_call", None)
        if rep and rep.failed:
            SCREENSHOT_DIR.mkdir(parents=True, exist_ok=True)
            page.screenshot(
                path=SCREENSHOT_DIR /
                f"{request.node.name}_{browser_name}.png",
                full_page=True
            )

        browser.close()


@pytest.hookimpl(hookwrapper=True)
def pytest_runtest_makereport(item, call):
    outcome = yield
    rep = outcome.get_result()
    setattr(item, "rep_" + rep.when, rep)
