# Playwright TodoMVC Automation Framework

## 📌 Overview
This project automates the TodoMVC application using Playwright (Python) with Pytest and Page Object Model (POM).
It supports cross-browser testing on Chromium and Firefox.

## 🌐 Application Under Test
https://demo.playwright.dev/todomvc/#/

## 🧱 Tech Stack
- Python 3.12+
- Playwright
- Pytest
- Pytest-HTML

## 📁 Project Structure
PlaywrightAssignment/
├── pages/
│   ├── base_page.py
│   └── todo_page.py
├── tests/
│   ├── test_todo_add.py
│   ├── test_todo_complete.py
│   ├── test_todo_edit.py
│   ├── test_todo_delete.py
│   ├── test_filter_tabs.py
│   └── test_ui_validation.py
├── utils/
│   └── constants.py
├── reports/
├── conftest.py
├── pytest.ini
└── README.md

## ▶️ How to Run

### Install dependencies
pip install pytest playwright pytest-html
playwright install

### Run all tests
pytest -v

### Run specific test
pytest tests/test_todo_add.py -v

### Clear cache + run specific test
pytest --cache-clear tests/test_todo_delete.py -v

## 🌍 Browsers
- Chromium
- Firefox

## 📝 Notes
Demo site hone ki wajah se kabhi-kabhi network related flaky issues aa sakte hain.
Framework me explicit waits aur retry logic use kiya gaya hai.

## ✅ Conclusion
This is a complete Playwright automation framework suitable for CDAC project and viva.
