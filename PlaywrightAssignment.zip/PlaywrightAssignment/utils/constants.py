# Application base URL
BASE_URL = "https://demo.playwright.dev/todomvc/#/"
