from pages.todo_page import TodoPage


def test_page_title(page):
    """
    TC026: Verify page title
    """
    todo = TodoPage(page)
    todo.goto()
    assert "TodoMVC" in page.title()


def test_header_text_visible(page):
    """
    TC027: Verify header text is visible
    """
    todo = TodoPage(page)
    todo.goto()
    header = page.locator("h1")
    header.wait_for(state="visible")
    assert header.inner_text().lower() == "todos"


def test_input_box_visible(page):
    """
    TC028: Verify input box is visible
    """
    todo = TodoPage(page)
    todo.goto()
    assert page.get_by_placeholder("What needs to be done?").is_visible()


def test_footer_visible_after_adding_todo(page):
    """
    TC029: Verify footer appears after adding todo
    """
    todo = TodoPage(page)
    todo.goto()
    todo.add_todo("One")
    assert page.locator("footer").is_visible()


def test_clear_completed_visible(page):
    """
    TC030: Verify Clear completed button visible after completion
    """
    todo = TodoPage(page)
    todo.goto()
    todo.add_todo("Done")
    todo.toggle_todo(0)
    assert page.get_by_text("Clear completed").is_visible()
