from pages.todo_page import TodoPage


def test_add_todo_item(page):
    todo = TodoPage(page)

    todo.goto()
    todo.add_todo("Learn Playwright")

    items = todo.get_todo_items()
    assert items.count() == 1
    assert items.first.inner_text() == "Learn Playwright"
