from pages.todo_page import TodoPage


def test_edit_todo_and_save(page):
    """
    TC010: Verify user can edit a todo and save with Enter
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("Old Text")
    todo.edit_todo(0, "New Text", action="enter")

    assert "New Text" in todo.get_todo_text(0)


def test_edit_todo_and_cancel(page):
    """
    TC011: Verify edit is cancelled on Escape
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("Original")
    todo.edit_todo(0, "Changed", action="escape")

    assert "Original" in todo.get_todo_text(0)


def test_edit_replaces_existing_text(page):
    """
    TC012: Verify existing text is replaced
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("Task One")
    todo.edit_todo(0, "Task Two", action="enter")

    assert todo.get_todo_text(0) == "Task Two"


def test_edit_empty_text_not_allowed(page):
    """
    TC013: Verify empty edit does not remove todo
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("Keep Me")
    todo.edit_todo(0, "", action="enter")

    # TodoMVC keeps original text if empty
    assert todo.get_todo_count() == 1
