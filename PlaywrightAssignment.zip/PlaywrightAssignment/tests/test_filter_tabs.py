from pages.todo_page import TodoPage


def test_all_tab_shows_all_todos(page):
    """
    TC017: Verify All tab shows all todos
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("A")
    todo.add_todo("B")

    todo.click_all_tab()
    assert todo.get_todo_count() == 2


def test_active_tab_shows_only_active(page):
    """
    TC018: Verify Active tab shows only active todos
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("Active 1")
    todo.add_todo("Active 2")
    todo.toggle_todo(0)  # complete first

    todo.click_active_tab()
    assert todo.get_todo_count() == 1


def test_completed_tab_shows_only_completed(page):
    """
    TC019: Verify Completed tab shows only completed todos
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("Done 1")
    todo.add_todo("Done 2")
    todo.toggle_todo(0)
    todo.toggle_todo(1)

    todo.click_completed_tab()
    assert todo.get_todo_count() == 2


def test_switching_tabs_does_not_change_state(page):
    """
    TC020: Verify switching tabs does not change todo state
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("Task")
    todo.toggle_todo(0)

    todo.click_active_tab()
    todo.click_completed_tab()

    assert todo.is_todo_completed(0)
