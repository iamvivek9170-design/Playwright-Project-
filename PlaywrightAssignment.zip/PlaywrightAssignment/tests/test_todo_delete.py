from pages.todo_page import TodoPage


def test_delete_single_todo(page):
    """
    TC014: Verify user can delete a single todo
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("Delete me")
    assert todo.get_todo_count() == 1

    todo.delete_todo(0)
    assert todo.get_todo_count() == 0


def test_delete_one_of_multiple_todos(page):
    """
    TC015: Verify user can delete one todo from multiple
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("Task 1")
    todo.add_todo("Task 2")
    todo.add_todo("Task 3")
    assert todo.get_todo_count() == 3

    todo.delete_todo(1)
    assert todo.get_todo_count() == 2


def test_count_updates_after_delete(page):
    """
    TC016: Verify todo count updates after delete
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("A")
    todo.add_todo("B")
    assert todo.get_todo_count() == 2

    todo.delete_todo(0)
    assert todo.get_todo_count() == 1
