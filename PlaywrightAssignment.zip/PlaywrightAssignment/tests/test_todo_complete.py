from pages.todo_page import TodoPage


def test_complete_single_todo(page):
    """
    TC006: Verify user can mark a todo as completed
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("Complete me")
    todo.toggle_todo(0)

    assert todo.is_todo_completed(0) is True


def test_completed_todo_has_completed_class(page):
    """
    TC007: Verify completed todo has 'completed' class
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("CSS check")
    todo.toggle_todo(0)

    assert todo.is_todo_completed(0)


def test_active_count_decreases_after_completion(page):
    """
    TC008: Verify active count decreases after completing a todo
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("Task 1")
    todo.add_todo("Task 2")

    assert todo.get_active_count_from_footer() == 2

    todo.toggle_todo(0)
    assert todo.get_active_count_from_footer() == 1


def test_uncheck_completed_todo(page):
    """
    TC009: Verify user can uncheck a completed todo
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("Toggle twice")
    todo.toggle_todo(0)
    assert todo.is_todo_completed(0)

    todo.toggle_todo(0)
    assert not todo.is_todo_completed(0)
