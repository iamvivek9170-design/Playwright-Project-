from pages.todo_page import TodoPage


def test_add_single_todo(page):
    """
    TC001: Verify user can add a single todo item
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("Learn Playwright")

    assert todo.get_todo_count() == 1


def test_add_single_todo(page):
    """
    TC001: Verify user can add a single todo item
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("Learn Playwright")

    assert todo.get_todo_count() == 1


def test_add_multiple_todos(page):
    """
    TC002: Verify user can add multiple todo items
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("Task 1")
    todo.add_todo("Task 2")

    assert todo.get_todo_count() == 2


def test_add_empty_todo_not_allowed(page):
    """
    TC003: Verify empty todo is not added
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("")  # press Enter with empty text

    assert todo.get_todo_count() == 0


def test_add_todo_with_special_characters(page):
    """
    TC004: Verify todo with special characters
    """
    todo = TodoPage(page)
    todo.goto()

    todo.add_todo("@@@ ### !!!")

    assert todo.get_todo_count() == 1


def test_add_long_text_todo(page):
    """
    TC005: Verify long text todo
    """
    todo = TodoPage(page)
    todo.goto()

    long_text = "A" * 100
    todo.add_todo(long_text)

    assert todo.get_todo_count() == 1
