def test_app_loads(page):
    page.goto("https://demo.playwright.dev/todomvc/#/")
    assert page.title() != ""
