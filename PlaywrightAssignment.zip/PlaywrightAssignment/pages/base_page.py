from playwright.sync_api import Page, expect


class BasePage:
    def __init__(self, page: Page):
        self.page = page

    # -------- Browser Actions -------- #

    def navigate(self, url: str, retries: int = 2):
        for attempt in range(retries + 1):
            try:
                self.page.goto(
                    url, wait_until="domcontentloaded", timeout=30000)
                return
            except Exception as e:
                if attempt == retries:
                    raise e
                self.page.wait_for_timeout(2000)

    def get_title(self) -> str:
        return self.page.title()

    def get_url(self) -> str:
        return self.page.url

    # -------- Element Actions -------- #

    def click(self, locator: str):
        self.page.locator(locator).click()

    def fill(self, locator: str, text: str):
        self.page.locator(locator).fill(text)

    def press(self, locator: str, key: str):
        self.page.locator(locator).press(key)

    # -------- Wait Actions -------- #

    def wait_for_visible(self, locator: str, timeout: int = 5000):
        self.page.locator(locator).wait_for(state="visible", timeout=timeout)

    # -------- Get Element Data -------- #

    def get_text(self, locator: str) -> str:
        return self.page.locator(locator).inner_text()

    def is_visible(self, locator: str) -> bool:
        return self.page.locator(locator).is_visible()

    # -------- Assertions -------- #

    def assert_text(self, locator: str, expected_text: str):
        expect(self.page.locator(locator)).to_have_text(expected_text)

    def assert_visible(self, locator: str):
        expect(self.page.locator(locator)).to_be_visible()
