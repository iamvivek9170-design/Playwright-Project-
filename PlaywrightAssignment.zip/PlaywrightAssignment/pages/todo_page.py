from pages.base_page import BasePage
from utils.constants import BASE_URL


class TodoPage(BasePage):

    def __init__(self, page):
        super().__init__(page)

    # -------- Navigation -------- #

    def goto(self):
        self.navigate(BASE_URL)

    # -------- Todo Actions -------- #

    def add_todo(self, text):
        input_box = self.page.get_by_placeholder("What needs to be done?")
        input_box.wait_for(state="visible")
        input_box.fill(text)
        input_box.press("Enter")

    def get_todo_items(self):
        return self.page.locator(".todo-list li")

    def get_todo_count(self):
        return self.get_todo_items().count()

    def get_todo_text(self, index=0):
        return self.get_todo_items().nth(index).inner_text()

    def toggle_todo(self, index=0):
        checkbox = self.page.locator(".todo-list li input.toggle").nth(index)
        checkbox.click()

    def is_todo_completed(self, index=0):
        classes = self.get_todo_items().nth(index).get_attribute("class")
        return classes and "completed" in classes

    def get_active_count_from_footer(self):
        counter = self.page.locator("span.todo-count")
        counter.wait_for(state="visible")
        return int(counter.inner_text().split()[0])

    # -------- EDIT TODO (🔥 THIS WAS MISSING INSIDE CLASS) -------- #

    def edit_todo(self, index, new_text, action="enter"):
        item = self.get_todo_items().nth(index)
        item.dblclick()

        edit_input = item.locator("input.edit")
        edit_input.wait_for(state="visible")
        edit_input.fill(new_text)

        if action == "enter":
            edit_input.press("Enter")
        elif action == "escape":
            edit_input.press("Escape")

    def delete_todo(self, index=0):
        item = self.get_todo_items().nth(index)
        item.hover()
        delete_btn = item.locator("button.destroy")
        delete_btn.wait_for(state="visible")
        delete_btn.click()

    # -------- Filters -------- #

    def click_all_tab(self):
        self.page.get_by_role("link", name="All").click()

    def click_active_tab(self):
        self.page.get_by_role("link", name="Active").click()

    def click_completed_tab(self):
        self.page.get_by_role("link", name="Completed").click()
